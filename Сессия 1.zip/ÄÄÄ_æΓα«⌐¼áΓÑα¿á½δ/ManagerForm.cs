﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ООО_Стройматериалы
{
    public partial class ManagerForm : Form
    {
        public ManagerForm()
        {
            InitializeComponent();
        }

        private void button_просмотр_Click(object sender, EventArgs e)
        {
            string connectionString = $@"Data Source = KAB17-06\SQLEXPRESS; Initial Catalog = Trade; Integrated Security = True";
            SqlConnection con = new SqlConnection(connectionString);
            string query = "select * from Product";
            SqlCommand com = new SqlCommand(query, con);
            SqlDataAdapter ad = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ООО_Стройматериалы
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string Nom = textBox_nom.Text;
                string Name = textBox_name.Text;
                string Desc = textBox_desc.Text;
                string Kat = textBox_kat.Text;
                string Proizv = textBox_proizv.Text;
                string Cost = textBox_cost.Text;
                string connectionString = $@"Data Source = KAB17-06\SQLEXPRESS; Initial Catalog = Trade; Integrated Security = True";
                SqlConnection con = new SqlConnection(connectionString);
                string query = $"insert into Product(ProductArticleNumber, ProductName, ProductDescription, ProductCategory, ProductPhoto, ProductManufacturer, ProductCost, ProductDiscountAmount, ProductQuantityInStock) values('{Nom}', '{Name}', '{Desc}', '{Kat}', NULL, '{Proizv}', '{Cost}', NULL, NULL); select * from Product";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter ad = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch(Exception ex)
            {
                DialogResult result = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_изменить_Click(object sender, EventArgs e)
        {
            try
            {
                string Nom = textBox_editnom.Text;
                string Name = textBox_editname.Text;
                string Cost = textBox_editcost.Text;
                string connectionString = $@"Data Source = KAB17-06\SQLEXPRESS; Initial Catalog = Trade; Integrated Security = True";
                SqlConnection con = new SqlConnection(connectionString);
                string query = $"update Product set ProductName = '{Name}', ProductCost = '{Cost}' where ProductArticleNumber = '{Nom}'; select * from Product";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter ad = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch(Exception ex)
            {
                DialogResult result = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string Nom = textBox_delnom.Text;
                string connectionString = $@"Data Source = KAB17-06\SQLEXPRESS; Initial Catalog = Trade; Integrated Security = True";
                SqlConnection con = new SqlConnection(connectionString);
                string query = $"delete from Product where ProductArticleNumber = '{Nom}'; select * from Product";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter ad = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch(Exception ex)
            {
                DialogResult result = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

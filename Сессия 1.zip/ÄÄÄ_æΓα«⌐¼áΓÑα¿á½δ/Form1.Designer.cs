﻿
namespace ООО_Стройматериалы
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_вход = new System.Windows.Forms.Button();
            this.textBox_логин = new System.Windows.Forms.TextBox();
            this.textBox_пароль = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_войти_как_гость = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_вход
            // 
            this.button_вход.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.button_вход.Location = new System.Drawing.Point(108, 202);
            this.button_вход.Name = "button_вход";
            this.button_вход.Size = new System.Drawing.Size(139, 33);
            this.button_вход.TabIndex = 0;
            this.button_вход.Text = "Войти";
            this.button_вход.UseVisualStyleBackColor = false;
            this.button_вход.Click += new System.EventHandler(this.button_вход_Click);
            // 
            // textBox_логин
            // 
            this.textBox_логин.Location = new System.Drawing.Point(124, 67);
            this.textBox_логин.Name = "textBox_логин";
            this.textBox_логин.Size = new System.Drawing.Size(192, 20);
            this.textBox_логин.TabIndex = 1;
            // 
            // textBox_пароль
            // 
            this.textBox_пароль.Location = new System.Drawing.Point(124, 119);
            this.textBox_пароль.Name = "textBox_пароль";
            this.textBox_пароль.Size = new System.Drawing.Size(192, 20);
            this.textBox_пароль.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Пароль";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.pictureBox1.Location = new System.Drawing.Point(-11, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(478, 26);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // button_войти_как_гость
            // 
            this.button_войти_как_гость.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.button_войти_как_гость.Location = new System.Drawing.Point(108, 241);
            this.button_войти_как_гость.Name = "button_войти_как_гость";
            this.button_войти_как_гость.Size = new System.Drawing.Size(139, 33);
            this.button_войти_как_гость.TabIndex = 6;
            this.button_войти_как_гость.Text = "Войти как гость";
            this.button_войти_как_гость.UseVisualStyleBackColor = false;
            this.button_войти_как_гость.Click += new System.EventHandler(this.button_войти_как_гость_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 286);
            this.Controls.Add(this.button_войти_как_гость);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_пароль);
            this.Controls.Add(this.textBox_логин);
            this.Controls.Add(this.button_вход);
            this.Name = "Form1";
            this.Text = "ООО Стройматериалы";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_вход;
        private System.Windows.Forms.TextBox textBox_логин;
        private System.Windows.Forms.TextBox textBox_пароль;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_войти_как_гость;
    }
}

